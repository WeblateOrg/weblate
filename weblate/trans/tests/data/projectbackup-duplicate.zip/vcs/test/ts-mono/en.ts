<!DOCTYPE TS>
<TS version="2.0" language="en">
<context>
    <name>Weblate</name>
    <message>
        <source>Hello</source>
        <translation>Hello, world!
</translation>
    </message>
    <message>
        <source>Orangutan</source>
        <translation>Orangutan has %d banana(s).
</translation>
    </message>
    <message>
        <source>Try</source>
        <translation>Try Weblate at &lt;https://demo.weblate.org/&gt;!</translation>
    </message>
    <message>
        <source>Thanks</source>
        <translation>Thank you for using Weblate.</translation>
    </message>
</context>
</TS>
