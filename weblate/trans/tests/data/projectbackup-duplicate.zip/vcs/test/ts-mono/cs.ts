
<!DOCTYPE TS>
<TS version="2.0" language="en">
<context>
    <name>Weblate</name>
    <message>
        <source>Hello</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orangutan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Try</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thanks</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
