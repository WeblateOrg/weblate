<a href="https://weblate.org/"><img alt="Weblate" src="https://s.weblate.org/cdn/Logo-Darktext-borders.png" height="80px" /></a>

**Weblate is a copylefted libre software web-based continuous localization system,
used by over 1150 libre projects and companies in more than 115 countries.**

Weblate Test Data
=================

This repository serves for testing Weblate and is used in its testsuite.

Please, do not submit pull request unless it is required by some testcase in
Weblate.
