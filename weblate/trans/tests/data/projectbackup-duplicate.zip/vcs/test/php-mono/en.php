<?php

$loc["hello"] = "Hello, world!\n";
$loc["banana"] = "Orangutan has %d banana.\n";
$loc["try"] = "Try Weblate at <https://demo.weblate.org/>!\n";
$loc["thanks"] = "Thank you for using Weblate.";
