<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>Test</name>
    <message>
        <source>Hello, world!
</source>
        <translation></translation>
    </message>
    <message numerus="yes">
        <source>Orangutan has %d banana(s).</source>
        <translation type="unfinished"><numerusform /><numerusform /><numerusform /></translation>
    </message>
    <message>
        <source>Try Weblate at &lt;https://demo.weblate.org/&gt;!</source>
        <translation></translation>
    </message>
    <message>
        <source>Thank you for using Weblate.</source>
        <translation type="unfinished">Thanks</translation>
    </message>
</context>
</TS>
