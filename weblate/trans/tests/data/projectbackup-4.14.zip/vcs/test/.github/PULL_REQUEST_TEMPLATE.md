This repository serves for testing Weblate <https://weblate.org/>.

Please, do not submit pull request unless it is required by some testcase in
Weblate.
