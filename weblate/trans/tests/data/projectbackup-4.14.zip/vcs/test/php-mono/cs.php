<?php

$loc["hello"] = "";
$loc["banana"] = "";
$loc["try"] = "";
$loc["thanks"] = "";
